USE [master]
GO
/****** Object:  Database [VetPet_BD2]    Script Date: 10/11/2023 11:12:28 ******/
CREATE DATABASE [VetPet_BD2]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'VetPet_BD2', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\VetPet_BD2.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'VetPet_BD2_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\VetPet_BD2_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [VetPet_BD2] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [VetPet_BD2].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [VetPet_BD2] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [VetPet_BD2] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [VetPet_BD2] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [VetPet_BD2] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [VetPet_BD2] SET ARITHABORT OFF 
GO
ALTER DATABASE [VetPet_BD2] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [VetPet_BD2] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [VetPet_BD2] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [VetPet_BD2] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [VetPet_BD2] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [VetPet_BD2] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [VetPet_BD2] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [VetPet_BD2] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [VetPet_BD2] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [VetPet_BD2] SET  ENABLE_BROKER 
GO
ALTER DATABASE [VetPet_BD2] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [VetPet_BD2] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [VetPet_BD2] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [VetPet_BD2] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [VetPet_BD2] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [VetPet_BD2] SET READ_COMMITTED_SNAPSHOT ON 
GO
ALTER DATABASE [VetPet_BD2] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [VetPet_BD2] SET RECOVERY FULL 
GO
ALTER DATABASE [VetPet_BD2] SET  MULTI_USER 
GO
ALTER DATABASE [VetPet_BD2] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [VetPet_BD2] SET DB_CHAINING OFF 
GO
ALTER DATABASE [VetPet_BD2] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [VetPet_BD2] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [VetPet_BD2] SET DELAYED_DURABILITY = DISABLED 
GO
EXEC sys.sp_db_vardecimal_storage_format N'VetPet_BD2', N'ON'
GO
ALTER DATABASE [VetPet_BD2] SET QUERY_STORE = OFF
GO
USE [VetPet_BD2]
GO
/****** Object:  Table [dbo].[__EFMigrationsHistory]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[__EFMigrationsHistory](
	[MigrationId] [nvarchar](150) NOT NULL,
	[ProductVersion] [nvarchar](32) NOT NULL,
 CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY CLUSTERED 
(
	[MigrationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Admins]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Admins](
	[adminId] [int] IDENTITY(1,1) NOT NULL,
	[nombres] [nvarchar](max) NULL,
	[apePaterno] [nvarchar](max) NULL,
	[apeMaterno] [nvarchar](max) NULL,
	[correo] [nvarchar](max) NULL,
	[contraseña] [nvarchar](max) NULL,
 CONSTRAINT [PK_Admins] PRIMARY KEY CLUSTERED 
(
	[adminId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AtencionMedica]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AtencionMedica](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[TituloAtentoMed] [nvarchar](max) NULL,
	[FechaAtenMed] [datetime2](7) NOT NULL,
	[MedicoId] [int] NULL,
	[MascotaId] [int] NULL,
	[DescripcionAtenMed] [nvarchar](max) NULL,
 CONSTRAINT [PK_AtencionMedica] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Categoria]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Categoria](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
 CONSTRAINT [PK_Categoria] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CitaMedica]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CitaMedica](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Motivo] [nvarchar](max) NULL,
	[SedeClinicaId] [int] NULL,
	[EspecialidadId] [int] NULL,
	[MedicoId] [int] NULL,
	[UsuarioId] [int] NULL,
	[MascotaId] [int] NULL,
	[FechaCita] [datetime2](7) NOT NULL,
	[TelefContacto] [nvarchar](max) NULL,
	[DetalleCita] [nvarchar](max) NULL,
	[AtencionMedicaId] [int] NULL,
	[HistorialMedicaId] [int] NULL,
 CONSTRAINT [PK_CitaMedica] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Enfermedades]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Enfermedades](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DescripcionEnferm] [nvarchar](max) NULL,
 CONSTRAINT [PK_Enfermedades] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Especialidad]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Especialidad](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
	[EspecialidadEntityId] [int] NULL,
 CONSTRAINT [PK_Especialidad] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EstadoCivil]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EstadoCivil](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
	[MedicoId] [int] NULL,
 CONSTRAINT [PK_EstadoCivil] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EstadoVacunas]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EstadoVacunas](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DescripcionVacunas] [int] NOT NULL,
 CONSTRAINT [PK_EstadoVacunas] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Genero]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Genero](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
	[MedicoId] [int] NULL,
	[MascotaId] [int] NULL,
	[UsuarioEntityId] [int] NULL,
 CONSTRAINT [PK_Genero] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[HistorialMedico]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[HistorialMedico](
	[Id] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_HistorialMedico] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Marca]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Marca](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
 CONSTRAINT [PK_Marca] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Mascota]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Mascota](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Imagen] [nvarchar](max) NULL,
	[Nombre] [nvarchar](max) NULL,
	[Apodo] [nvarchar](max) NULL,
	[RazaId] [int] NULL,
	[FechaAdopcion] [datetime2](7) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
	[Comentario] [nvarchar](max) NULL,
	[UsuarioId] [int] NULL,
	[HistorialMedicoId] [int] NULL,
	[MascotaEntityId] [int] NULL,
 CONSTRAINT [PK_Mascota] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MascotaEnfermedades]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MascotaEnfermedades](
	[MascotaId] [int] NOT NULL,
	[EnfermedadesId] [int] NOT NULL,
 CONSTRAINT [PK_MascotaEnfermedades] PRIMARY KEY CLUSTERED 
(
	[MascotaId] ASC,
	[EnfermedadesId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MascotaVacunas]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MascotaVacunas](
	[MascotaId] [int] NOT NULL,
	[EstadoVacunasId] [int] NOT NULL,
 CONSTRAINT [PK_MascotaVacunas] PRIMARY KEY CLUSTERED 
(
	[MascotaId] ASC,
	[EstadoVacunasId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Medicacion]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Medicacion](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[DescripcionMedicamento] [nvarchar](max) NULL,
	[MascotaId] [int] NULL,
 CONSTRAINT [PK_Medicacion] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Medico]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Medico](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Imagen] [nvarchar](max) NULL,
	[Nombre] [nvarchar](max) NULL,
	[Apellido] [nvarchar](max) NULL,
	[NumeroDocumento] [nvarchar](max) NULL,
	[Telefono1] [nvarchar](max) NULL,
	[Telefono2] [nvarchar](max) NULL,
	[Direccion] [nvarchar](max) NULL,
	[SedeClinicaId] [int] NOT NULL,
	[SedeClinicaEntityId] [int] NULL,
	[FechaNacimiento] [datetime2](7) NOT NULL,
	[EspecialidadEntityId] [int] NULL,
	[DescripProfesional] [nvarchar](max) NULL,
	[Correo] [nvarchar](max) NULL,
	[Contrasena] [nvarchar](max) NULL,
	[HistorialMedicoId] [int] NULL,
 CONSTRAINT [PK_Medico] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Producto]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Producto](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Imagen] [nvarchar](max) NULL,
	[Nonbre] [nvarchar](max) NULL,
	[DescripcionProd] [nvarchar](max) NULL,
	[CaracteristicasProd] [nvarchar](max) NULL,
	[MarcaId] [int] NULL,
	[CategoriaId] [int] NULL,
	[TipoAnimalId] [int] NULL,
	[SKU] [nvarchar](max) NULL,
	[Precio] [float] NOT NULL,
	[Stock] [int] NOT NULL,
 CONSTRAINT [PK_Producto] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Raza]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Raza](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
 CONSTRAINT [PK_Raza] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SedeClinica]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SedeClinica](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nombre] [nvarchar](max) NULL,
	[Direccion] [nvarchar](max) NULL,
 CONSTRAINT [PK_SedeClinica] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TipoAnimal]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TipoAnimal](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
 CONSTRAINT [PK_TipoAnimal] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TipoDocumento]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TipoDocumento](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Descripcion] [nvarchar](max) NULL,
	[MedicoId] [int] NULL,
	[UsuarioEntityId] [int] NULL,
 CONSTRAINT [PK_TipoDocumento] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Usuario]    Script Date: 10/11/2023 11:12:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Usuario](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Imagen] [nvarchar](max) NULL,
	[Apellido] [nvarchar](max) NULL,
	[NumeroDocumento] [nvarchar](max) NULL,
	[Telefono] [nvarchar](max) NULL,
	[Direccion] [nvarchar](max) NULL,
	[FechaNacimiento] [datetime2](7) NOT NULL,
	[Correo] [nvarchar](max) NULL,
	[Contrasena] [nvarchar](max) NULL,
 CONSTRAINT [PK_Usuario] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
INSERT [dbo].[__EFMigrationsHistory] ([MigrationId], [ProductVersion]) VALUES (N'20231009162303_FirstMigration', N'3.1.0')
GO
SET IDENTITY_INSERT [dbo].[Admins] ON 
GO
INSERT [dbo].[Admins] ([adminId], [nombres], [apePaterno], [apeMaterno], [correo], [contraseña]) VALUES (1, N'Angelo', N'Espinoza', N'Picoy', N'angelos260303@gmail.com', N'contraseña26')
GO
INSERT [dbo].[Admins] ([adminId], [nombres], [apePaterno], [apeMaterno], [correo], [contraseña]) VALUES (2, N'Alejandro', N'Quispe', N'Marquez', N'a@gmail.com', N'a')
GO
SET IDENTITY_INSERT [dbo].[Admins] OFF
GO
SET IDENTITY_INSERT [dbo].[Categoria] ON 
GO
INSERT [dbo].[Categoria] ([Id], [Descripcion]) VALUES (4, N'Comida')
GO
INSERT [dbo].[Categoria] ([Id], [Descripcion]) VALUES (5, N'Medicamento')
GO
INSERT [dbo].[Categoria] ([Id], [Descripcion]) VALUES (6, N'Accesorio')
GO
INSERT [dbo].[Categoria] ([Id], [Descripcion]) VALUES (7, N'Ropa')
GO
INSERT [dbo].[Categoria] ([Id], [Descripcion]) VALUES (8, N'Juguetes')
GO
SET IDENTITY_INSERT [dbo].[Categoria] OFF
GO
SET IDENTITY_INSERT [dbo].[Marca] ON 
GO
INSERT [dbo].[Marca] ([Id], [Descripcion]) VALUES (1, N'Pedigree')
GO
INSERT [dbo].[Marca] ([Id], [Descripcion]) VALUES (2, N'Ricocan')
GO
INSERT [dbo].[Marca] ([Id], [Descripcion]) VALUES (3, N'TotalFull')
GO
INSERT [dbo].[Marca] ([Id], [Descripcion]) VALUES (4, N'LCFC')
GO
INSERT [dbo].[Marca] ([Id], [Descripcion]) VALUES (5, N'FPF')
GO
SET IDENTITY_INSERT [dbo].[Marca] OFF
GO
SET IDENTITY_INSERT [dbo].[Producto] ON 
GO
INSERT [dbo].[Producto] ([Id], [Imagen], [Nonbre], [DescripcionProd], [CaracteristicasProd], [MarcaId], [CategoriaId], [TipoAnimalId], [SKU], [Precio], [Stock]) VALUES (1, N'pedigree.jpg', N'Pedigree', N'Comida para Perros Pedigree', N'Sabor a Carne , Pollo y Cereales', 2, 4, 1, N'123456789', 61, 100)
GO
INSERT [dbo].[Producto] ([Id], [Imagen], [Nonbre], [DescripcionProd], [CaracteristicasProd], [MarcaId], [CategoriaId], [TipoAnimalId], [SKU], [Precio], [Stock]) VALUES (5, N'ricocan.jpg', N'Ricocan', N'Comida de Perros Ricocan', N'Adulto Bolsa de 16kg', 2, 4, 2, N'78542234', 131, 100)
GO
INSERT [dbo].[Producto] ([Id], [Imagen], [Nonbre], [DescripcionProd], [CaracteristicasProd], [MarcaId], [CategoriaId], [TipoAnimalId], [SKU], [Precio], [Stock]) VALUES (6, N'totalfull.jpg', N'TotalFull', N'Antiparasitario', N'Antiparasitario Interno Palatable para Gatos ', 3, 5, 2, N'7412546216', 350, 100)
GO
INSERT [dbo].[Producto] ([Id], [Imagen], [Nonbre], [DescripcionProd], [CaracteristicasProd], [MarcaId], [CategoriaId], [TipoAnimalId], [SKU], [Precio], [Stock]) VALUES (8, N'correaleicester.jpg', N'Correa Retractil ', N'Correa Retractil Leicester City Fc', N'Correa Rectractil para perros del Equipo Leicester City', 4, 6, 1, N'3454575467412', 60, 100)
GO
INSERT [dbo].[Producto] ([Id], [Imagen], [Nonbre], [DescripcionProd], [CaracteristicasProd], [MarcaId], [CategoriaId], [TipoAnimalId], [SKU], [Precio], [Stock]) VALUES (19, N'poloperu.jpg', N'Polo Perú', N'Polo Seleccion Peruana', N'Polo de la seleccion peruana para mascota', 5, 7, 1, N'789456123', 25, 100)
GO
SET IDENTITY_INSERT [dbo].[Producto] OFF
GO
SET IDENTITY_INSERT [dbo].[TipoAnimal] ON 
GO
INSERT [dbo].[TipoAnimal] ([Id], [Descripcion]) VALUES (1, N'Perro')
GO
INSERT [dbo].[TipoAnimal] ([Id], [Descripcion]) VALUES (2, N'Gato')
GO
INSERT [dbo].[TipoAnimal] ([Id], [Descripcion]) VALUES (3, N'Otros')
GO
SET IDENTITY_INSERT [dbo].[TipoAnimal] OFF
GO
/****** Object:  Index [IX_AtencionMedica_MascotaId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_AtencionMedica_MascotaId] ON [dbo].[AtencionMedica]
(
	[MascotaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_AtencionMedica_MedicoId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_AtencionMedica_MedicoId] ON [dbo].[AtencionMedica]
(
	[MedicoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CitaMedica_AtencionMedicaId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_CitaMedica_AtencionMedicaId] ON [dbo].[CitaMedica]
(
	[AtencionMedicaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CitaMedica_EspecialidadId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_CitaMedica_EspecialidadId] ON [dbo].[CitaMedica]
(
	[EspecialidadId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CitaMedica_HistorialMedicaId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_CitaMedica_HistorialMedicaId] ON [dbo].[CitaMedica]
(
	[HistorialMedicaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CitaMedica_MascotaId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_CitaMedica_MascotaId] ON [dbo].[CitaMedica]
(
	[MascotaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CitaMedica_MedicoId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_CitaMedica_MedicoId] ON [dbo].[CitaMedica]
(
	[MedicoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CitaMedica_SedeClinicaId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_CitaMedica_SedeClinicaId] ON [dbo].[CitaMedica]
(
	[SedeClinicaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_CitaMedica_UsuarioId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_CitaMedica_UsuarioId] ON [dbo].[CitaMedica]
(
	[UsuarioId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Especialidad_EspecialidadEntityId]    Script Date: 10/11/2023 11:12:28 ******/
CREATE NONCLUSTERED INDEX [IX_Especialidad_EspecialidadEntityId] ON [dbo].[Especialidad]
(
	[EspecialidadEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_EstadoCivil_MedicoId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_EstadoCivil_MedicoId] ON [dbo].[EstadoCivil]
(
	[MedicoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Genero_MascotaId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Genero_MascotaId] ON [dbo].[Genero]
(
	[MascotaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Genero_MedicoId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Genero_MedicoId] ON [dbo].[Genero]
(
	[MedicoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Genero_UsuarioEntityId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Genero_UsuarioEntityId] ON [dbo].[Genero]
(
	[UsuarioEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Mascota_HistorialMedicoId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Mascota_HistorialMedicoId] ON [dbo].[Mascota]
(
	[HistorialMedicoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Mascota_MascotaEntityId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Mascota_MascotaEntityId] ON [dbo].[Mascota]
(
	[MascotaEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Mascota_RazaId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Mascota_RazaId] ON [dbo].[Mascota]
(
	[RazaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Mascota_UsuarioId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Mascota_UsuarioId] ON [dbo].[Mascota]
(
	[UsuarioId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_MascotaEnfermedades_EnfermedadesId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_MascotaEnfermedades_EnfermedadesId] ON [dbo].[MascotaEnfermedades]
(
	[EnfermedadesId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_MascotaVacunas_EstadoVacunasId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_MascotaVacunas_EstadoVacunasId] ON [dbo].[MascotaVacunas]
(
	[EstadoVacunasId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Medicacion_MascotaId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Medicacion_MascotaId] ON [dbo].[Medicacion]
(
	[MascotaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Medico_EspecialidadEntityId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Medico_EspecialidadEntityId] ON [dbo].[Medico]
(
	[EspecialidadEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Medico_HistorialMedicoId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Medico_HistorialMedicoId] ON [dbo].[Medico]
(
	[HistorialMedicoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Medico_SedeClinicaEntityId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Medico_SedeClinicaEntityId] ON [dbo].[Medico]
(
	[SedeClinicaEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Producto_CategoriaId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Producto_CategoriaId] ON [dbo].[Producto]
(
	[CategoriaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Producto_MarcaId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Producto_MarcaId] ON [dbo].[Producto]
(
	[MarcaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Producto_TipoAnimalId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_Producto_TipoAnimalId] ON [dbo].[Producto]
(
	[TipoAnimalId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_TipoDocumento_MedicoId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_TipoDocumento_MedicoId] ON [dbo].[TipoDocumento]
(
	[MedicoId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_TipoDocumento_UsuarioEntityId]    Script Date: 10/11/2023 11:12:29 ******/
CREATE NONCLUSTERED INDEX [IX_TipoDocumento_UsuarioEntityId] ON [dbo].[TipoDocumento]
(
	[UsuarioEntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AtencionMedica]  WITH CHECK ADD  CONSTRAINT [FK_AtencionMedica_Mascota_MascotaId] FOREIGN KEY([MascotaId])
REFERENCES [dbo].[Mascota] ([Id])
GO
ALTER TABLE [dbo].[AtencionMedica] CHECK CONSTRAINT [FK_AtencionMedica_Mascota_MascotaId]
GO
ALTER TABLE [dbo].[AtencionMedica]  WITH CHECK ADD  CONSTRAINT [FK_AtencionMedica_Medico_MedicoId] FOREIGN KEY([MedicoId])
REFERENCES [dbo].[Medico] ([Id])
GO
ALTER TABLE [dbo].[AtencionMedica] CHECK CONSTRAINT [FK_AtencionMedica_Medico_MedicoId]
GO
ALTER TABLE [dbo].[CitaMedica]  WITH CHECK ADD  CONSTRAINT [FK_CitaMedica_AtencionMedica_AtencionMedicaId] FOREIGN KEY([AtencionMedicaId])
REFERENCES [dbo].[AtencionMedica] ([Id])
GO
ALTER TABLE [dbo].[CitaMedica] CHECK CONSTRAINT [FK_CitaMedica_AtencionMedica_AtencionMedicaId]
GO
ALTER TABLE [dbo].[CitaMedica]  WITH CHECK ADD  CONSTRAINT [FK_CitaMedica_Especialidad_EspecialidadId] FOREIGN KEY([EspecialidadId])
REFERENCES [dbo].[Especialidad] ([Id])
GO
ALTER TABLE [dbo].[CitaMedica] CHECK CONSTRAINT [FK_CitaMedica_Especialidad_EspecialidadId]
GO
ALTER TABLE [dbo].[CitaMedica]  WITH CHECK ADD  CONSTRAINT [FK_CitaMedica_HistorialMedico_HistorialMedicaId] FOREIGN KEY([HistorialMedicaId])
REFERENCES [dbo].[HistorialMedico] ([Id])
GO
ALTER TABLE [dbo].[CitaMedica] CHECK CONSTRAINT [FK_CitaMedica_HistorialMedico_HistorialMedicaId]
GO
ALTER TABLE [dbo].[CitaMedica]  WITH CHECK ADD  CONSTRAINT [FK_CitaMedica_Mascota_MascotaId] FOREIGN KEY([MascotaId])
REFERENCES [dbo].[Mascota] ([Id])
GO
ALTER TABLE [dbo].[CitaMedica] CHECK CONSTRAINT [FK_CitaMedica_Mascota_MascotaId]
GO
ALTER TABLE [dbo].[CitaMedica]  WITH CHECK ADD  CONSTRAINT [FK_CitaMedica_Medico_MedicoId] FOREIGN KEY([MedicoId])
REFERENCES [dbo].[Medico] ([Id])
GO
ALTER TABLE [dbo].[CitaMedica] CHECK CONSTRAINT [FK_CitaMedica_Medico_MedicoId]
GO
ALTER TABLE [dbo].[CitaMedica]  WITH CHECK ADD  CONSTRAINT [FK_CitaMedica_SedeClinica_SedeClinicaId] FOREIGN KEY([SedeClinicaId])
REFERENCES [dbo].[SedeClinica] ([Id])
GO
ALTER TABLE [dbo].[CitaMedica] CHECK CONSTRAINT [FK_CitaMedica_SedeClinica_SedeClinicaId]
GO
ALTER TABLE [dbo].[CitaMedica]  WITH CHECK ADD  CONSTRAINT [FK_CitaMedica_Usuario_UsuarioId] FOREIGN KEY([UsuarioId])
REFERENCES [dbo].[Usuario] ([Id])
GO
ALTER TABLE [dbo].[CitaMedica] CHECK CONSTRAINT [FK_CitaMedica_Usuario_UsuarioId]
GO
ALTER TABLE [dbo].[Especialidad]  WITH CHECK ADD  CONSTRAINT [FK_Especialidad_Especialidad_EspecialidadEntityId] FOREIGN KEY([EspecialidadEntityId])
REFERENCES [dbo].[Especialidad] ([Id])
GO
ALTER TABLE [dbo].[Especialidad] CHECK CONSTRAINT [FK_Especialidad_Especialidad_EspecialidadEntityId]
GO
ALTER TABLE [dbo].[EstadoCivil]  WITH CHECK ADD  CONSTRAINT [FK_EstadoCivil_Medico_MedicoId] FOREIGN KEY([MedicoId])
REFERENCES [dbo].[Medico] ([Id])
GO
ALTER TABLE [dbo].[EstadoCivil] CHECK CONSTRAINT [FK_EstadoCivil_Medico_MedicoId]
GO
ALTER TABLE [dbo].[Genero]  WITH CHECK ADD  CONSTRAINT [FK_Genero_Mascota_MascotaId] FOREIGN KEY([MascotaId])
REFERENCES [dbo].[Mascota] ([Id])
GO
ALTER TABLE [dbo].[Genero] CHECK CONSTRAINT [FK_Genero_Mascota_MascotaId]
GO
ALTER TABLE [dbo].[Genero]  WITH CHECK ADD  CONSTRAINT [FK_Genero_Medico_MedicoId] FOREIGN KEY([MedicoId])
REFERENCES [dbo].[Medico] ([Id])
GO
ALTER TABLE [dbo].[Genero] CHECK CONSTRAINT [FK_Genero_Medico_MedicoId]
GO
ALTER TABLE [dbo].[Genero]  WITH CHECK ADD  CONSTRAINT [FK_Genero_Usuario_UsuarioEntityId] FOREIGN KEY([UsuarioEntityId])
REFERENCES [dbo].[Usuario] ([Id])
GO
ALTER TABLE [dbo].[Genero] CHECK CONSTRAINT [FK_Genero_Usuario_UsuarioEntityId]
GO
ALTER TABLE [dbo].[Mascota]  WITH CHECK ADD  CONSTRAINT [FK_Mascota_HistorialMedico_HistorialMedicoId] FOREIGN KEY([HistorialMedicoId])
REFERENCES [dbo].[HistorialMedico] ([Id])
GO
ALTER TABLE [dbo].[Mascota] CHECK CONSTRAINT [FK_Mascota_HistorialMedico_HistorialMedicoId]
GO
ALTER TABLE [dbo].[Mascota]  WITH CHECK ADD  CONSTRAINT [FK_Mascota_Mascota_MascotaEntityId] FOREIGN KEY([MascotaEntityId])
REFERENCES [dbo].[Mascota] ([Id])
GO
ALTER TABLE [dbo].[Mascota] CHECK CONSTRAINT [FK_Mascota_Mascota_MascotaEntityId]
GO
ALTER TABLE [dbo].[Mascota]  WITH CHECK ADD  CONSTRAINT [FK_Mascota_Raza_RazaId] FOREIGN KEY([RazaId])
REFERENCES [dbo].[Raza] ([Id])
GO
ALTER TABLE [dbo].[Mascota] CHECK CONSTRAINT [FK_Mascota_Raza_RazaId]
GO
ALTER TABLE [dbo].[Mascota]  WITH CHECK ADD  CONSTRAINT [FK_Mascota_Usuario_UsuarioId] FOREIGN KEY([UsuarioId])
REFERENCES [dbo].[Usuario] ([Id])
GO
ALTER TABLE [dbo].[Mascota] CHECK CONSTRAINT [FK_Mascota_Usuario_UsuarioId]
GO
ALTER TABLE [dbo].[MascotaEnfermedades]  WITH CHECK ADD  CONSTRAINT [FK_MascotaEnfermedades_Enfermedades_EnfermedadesId] FOREIGN KEY([EnfermedadesId])
REFERENCES [dbo].[Enfermedades] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MascotaEnfermedades] CHECK CONSTRAINT [FK_MascotaEnfermedades_Enfermedades_EnfermedadesId]
GO
ALTER TABLE [dbo].[MascotaEnfermedades]  WITH CHECK ADD  CONSTRAINT [FK_MascotaEnfermedades_Mascota_MascotaId] FOREIGN KEY([MascotaId])
REFERENCES [dbo].[Mascota] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MascotaEnfermedades] CHECK CONSTRAINT [FK_MascotaEnfermedades_Mascota_MascotaId]
GO
ALTER TABLE [dbo].[MascotaVacunas]  WITH CHECK ADD  CONSTRAINT [FK_MascotaVacunas_EstadoVacunas_EstadoVacunasId] FOREIGN KEY([EstadoVacunasId])
REFERENCES [dbo].[EstadoVacunas] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MascotaVacunas] CHECK CONSTRAINT [FK_MascotaVacunas_EstadoVacunas_EstadoVacunasId]
GO
ALTER TABLE [dbo].[MascotaVacunas]  WITH CHECK ADD  CONSTRAINT [FK_MascotaVacunas_Mascota_MascotaId] FOREIGN KEY([MascotaId])
REFERENCES [dbo].[Mascota] ([Id])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[MascotaVacunas] CHECK CONSTRAINT [FK_MascotaVacunas_Mascota_MascotaId]
GO
ALTER TABLE [dbo].[Medicacion]  WITH CHECK ADD  CONSTRAINT [FK_Medicacion_Mascota_MascotaId] FOREIGN KEY([MascotaId])
REFERENCES [dbo].[Mascota] ([Id])
GO
ALTER TABLE [dbo].[Medicacion] CHECK CONSTRAINT [FK_Medicacion_Mascota_MascotaId]
GO
ALTER TABLE [dbo].[Medico]  WITH CHECK ADD  CONSTRAINT [FK_Medico_Especialidad_EspecialidadEntityId] FOREIGN KEY([EspecialidadEntityId])
REFERENCES [dbo].[Especialidad] ([Id])
GO
ALTER TABLE [dbo].[Medico] CHECK CONSTRAINT [FK_Medico_Especialidad_EspecialidadEntityId]
GO
ALTER TABLE [dbo].[Medico]  WITH CHECK ADD  CONSTRAINT [FK_Medico_HistorialMedico_HistorialMedicoId] FOREIGN KEY([HistorialMedicoId])
REFERENCES [dbo].[HistorialMedico] ([Id])
GO
ALTER TABLE [dbo].[Medico] CHECK CONSTRAINT [FK_Medico_HistorialMedico_HistorialMedicoId]
GO
ALTER TABLE [dbo].[Medico]  WITH CHECK ADD  CONSTRAINT [FK_Medico_SedeClinica_SedeClinicaEntityId] FOREIGN KEY([SedeClinicaEntityId])
REFERENCES [dbo].[SedeClinica] ([Id])
GO
ALTER TABLE [dbo].[Medico] CHECK CONSTRAINT [FK_Medico_SedeClinica_SedeClinicaEntityId]
GO
ALTER TABLE [dbo].[Producto]  WITH CHECK ADD  CONSTRAINT [FK_Producto_Categoria_CategoriaId] FOREIGN KEY([CategoriaId])
REFERENCES [dbo].[Categoria] ([Id])
GO
ALTER TABLE [dbo].[Producto] CHECK CONSTRAINT [FK_Producto_Categoria_CategoriaId]
GO
ALTER TABLE [dbo].[Producto]  WITH CHECK ADD  CONSTRAINT [FK_Producto_Marca_MarcaId] FOREIGN KEY([MarcaId])
REFERENCES [dbo].[Marca] ([Id])
GO
ALTER TABLE [dbo].[Producto] CHECK CONSTRAINT [FK_Producto_Marca_MarcaId]
GO
ALTER TABLE [dbo].[Producto]  WITH CHECK ADD  CONSTRAINT [FK_Producto_TipoAnimal_TipoAnimalId] FOREIGN KEY([TipoAnimalId])
REFERENCES [dbo].[TipoAnimal] ([Id])
GO
ALTER TABLE [dbo].[Producto] CHECK CONSTRAINT [FK_Producto_TipoAnimal_TipoAnimalId]
GO
ALTER TABLE [dbo].[TipoDocumento]  WITH CHECK ADD  CONSTRAINT [FK_TipoDocumento_Medico_MedicoId] FOREIGN KEY([MedicoId])
REFERENCES [dbo].[Medico] ([Id])
GO
ALTER TABLE [dbo].[TipoDocumento] CHECK CONSTRAINT [FK_TipoDocumento_Medico_MedicoId]
GO
ALTER TABLE [dbo].[TipoDocumento]  WITH CHECK ADD  CONSTRAINT [FK_TipoDocumento_Usuario_UsuarioEntityId] FOREIGN KEY([UsuarioEntityId])
REFERENCES [dbo].[Usuario] ([Id])
GO
ALTER TABLE [dbo].[TipoDocumento] CHECK CONSTRAINT [FK_TipoDocumento_Usuario_UsuarioEntityId]
GO
USE [master]
GO
ALTER DATABASE [VetPet_BD2] SET  READ_WRITE 
GO
