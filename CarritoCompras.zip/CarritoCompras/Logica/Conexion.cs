﻿namespace CarritoCompras.Logica
{
    public class Conexion
    {
        public static string CN = "Data Source=.;Initial Catalog=vetpetBD;Integrated Security=True";
    }
}