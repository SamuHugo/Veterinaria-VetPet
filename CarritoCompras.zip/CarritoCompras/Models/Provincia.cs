﻿namespace CarritoCompras.Models
{
    public class Provincia
    {
        public string IdProvincia { get; set; }
        public string Descripcion { get; set; }
        public string IdDepartamento { get; set; }
    }
}