﻿namespace CarritoCompras.Models
{
    public class Departamento
    {
        public string IdDepartamento { get; set; }
        public string Descripcion { get; set; }
    }
}